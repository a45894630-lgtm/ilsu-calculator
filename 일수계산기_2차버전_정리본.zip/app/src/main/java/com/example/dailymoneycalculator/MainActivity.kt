package com.example.dailymoneycalculator

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

data class Customer(
    val name: String,
    val phone: String,
    val principal: Long,
    val daily: Long,
    val startDate: String
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("daily_money_data", MODE_PRIVATE) }
    private val moneyFormat = NumberFormat.getNumberInstance(Locale.KOREA)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)

    private lateinit var customerList: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var principalInput: EditText
    private lateinit var dailyInput: EditText
    private lateinit var startInput: EditText

    private fun money(value: Long): String = "${moneyFormat.format(value)}원"

    private fun input(hint: String, numeric: Boolean = false): EditText {
        return EditText(this).apply {
            this.hint = hint
            textSize = 18f
            setSingleLine(true)
            setPadding(16, 8, 16, 8)
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 62
            ).apply { setMargins(0, 4, 0, 8) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 20)
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "일수 계산기"
            textSize = 30f
            setTextColor(Color.BLACK)
            setPadding(0, 4, 0, 8)
        })

        root.addView(TextView(this).apply {
            text = "원금은 별도 관리 · 하루 일수금 × 경과일"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, 14)
        })

        nameInput = input("고객 이름")
        phoneInput = input("전화번호", true)
        principalInput = input("원금 (원)", true)
        dailyInput = input("하루 일수금 (원)", true)
        startInput = input("시작일 (YYYY-MM-DD)")
        startInput.setText(dateFormat.format(Date()))

        root.addView(nameInput)
        root.addView(phoneInput)
        root.addView(principalInput)
        root.addView(dailyInput)
        root.addView(startInput)

        val saveButton = Button(this).apply {
            text = "고객 저장"
            textSize = 19f
        }
        root.addView(saveButton, LinearLayout.LayoutParams(-1, 64).apply {
            setMargins(0, 4, 0, 12)
        })

        root.addView(TextView(this).apply {
            text = "등록 고객"
            textSize = 22f
            setTextColor(Color.BLACK)
            setPadding(0, 4, 0, 8)
        })

        customerList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val scroll = ScrollView(this)
        scroll.addView(customerList)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        saveButton.setOnClickListener { saveCustomer() }
        refreshCustomers()
    }

    private fun saveCustomer() {
        val name = nameInput.text.toString().trim()
        val phone = phoneInput.text.toString().trim()
        val principal = principalInput.text.toString().toLongOrNull() ?: 0L
        val daily = dailyInput.text.toString().toLongOrNull() ?: 0L
        val start = startInput.text.toString().trim()

        if (name.isEmpty() || principal <= 0 || daily <= 0) {
            Toast.makeText(this, "이름, 원금, 하루 일수금을 입력하세요.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            dateFormat.isLenient = false
            dateFormat.parse(start)
        } catch (_: Exception) {
            Toast.makeText(this, "시작일은 YYYY-MM-DD 형식으로 입력하세요.", Toast.LENGTH_SHORT).show()
            return
        }

        val record = encode(Customer(name, phone, principal, daily, start))
        val records = prefs.getStringSet("customers", emptySet())!!.toMutableSet()
        records.add(record)
        prefs.edit().putStringSet("customers", records).apply()

        nameInput.text.clear()
        phoneInput.text.clear()
        principalInput.text.clear()
        dailyInput.text.clear()

        Toast.makeText(this, "고객이 저장되었습니다.", Toast.LENGTH_SHORT).show()
        refreshCustomers()
    }

    private fun encode(c: Customer): String =
        listOf(c.name, c.phone, c.principal, c.daily, c.startDate)
            .joinToString("|")

    private fun decode(value: String): Customer? {
        val a = value.split("|")
        if (a.size != 5) return null
        return Customer(
            a[0], a[1],
            a[2].toLongOrNull() ?: return null,
            a[3].toLongOrNull() ?: return null,
            a[4]
        )
    }

    private fun refreshCustomers() {
        if (!::customerList.isInitialized) return
        customerList.removeAllViews()

        val customers = prefs.getStringSet("customers", emptySet())!!
            .mapNotNull { decode(it) }

        if (customers.isEmpty()) {
            customerList.addView(TextView(this).apply {
                text = "등록된 고객이 없습니다."
                textSize = 17f
                setPadding(0, 12, 0, 12)
            })
            return
        }

        customers.forEach { customer ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 14, 16, 14)
                setBackgroundColor(0xFFF3F6F9.toInt())
            }

            val info = TextView(this).apply {
                text = customerSummary(customer)
                textSize = 17f
                setTextColor(Color.BLACK)
            }

            val detail = Button(this).apply {
                text = "상세 / 받은 금액 기록"
                textSize = 17f
            }

            box.addView(info)
            box.addView(detail)

            detail.setOnClickListener { showCustomerDetail(customer) }

            customerList.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 0, 0, 10)
            })
        }
    }

    private fun elapsedDays(start: String): Long {
        return try {
            dateFormat.isLenient = false
            val startTime = dateFormat.parse(start)!!.time
            max(0L, ((Date().time - startTime) / 86_400_000L) + 1L)
        } catch (_: Exception) {
            0L
        }
    }

    private fun paymentKey(c: Customer): String =
        "payment_${c.name}_${c.phone}_${c.startDate}_${c.principal}_${c.daily}"

    private fun received(c: Customer): Long =
        prefs.getLong(paymentKey(c), 0L)

    private fun accumulated(c: Customer): Long =
        c.daily * elapsedDays(c.startDate)

    private fun remaining(c: Customer): Long =
        max(0L, accumulated(c) - received(c))

    private fun customerSummary(c: Customer): String {
        val days = elapsedDays(c.startDate)
        return buildString {
            append("${c.name}
")
            if (c.phone.isNotEmpty()) append("전화: ${c.phone}
")
            append("원금: ${money(c.principal)}
")
            append("시작일: ${c.startDate}  ·  경과 ${days}일
")
            append("하루 일수금: ${money(c.daily)}
")
            append("누적 일수금: ${money(accumulated(c))}
")
            append("받은 금액: ${money(received(c))}
")
            append("남은 일수금: ${money(remaining(c))}")
        }
    }

    private fun showCustomerDetail(c: Customer) {
        val receivedNow = received(c)
        val input = EditText(this).apply {
            hint = "이번에 받은 금액 (원)"
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 20f
        }

        val message = buildString {
            append("원금: ${money(c.principal)}
")
            append("하루 일수금: ${money(c.daily)}
")
            append("경과일: ${elapsedDays(c.startDate)}일
")
            append("누적 일수금: ${money(accumulated(c))}
")
            append("지금까지 받은 금액: ${money(receivedNow)}
")
            append("현재 남은 일수금: ${money(remaining(c))}")
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(c.name)
            .setMessage(message)
            .setView(input)
            .setPositiveButton("기록") { _, _ ->
                val amount = input.text.toString().toLongOrNull() ?: 0L
                if (amount > 0) {
                    prefs.edit().putLong(paymentKey(c), receivedNow + amount).apply()
                    refreshCustomers()
                    Toast.makeText(this, "받은 금액이 기록되었습니다.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("삭제") { _, _ -> confirmDelete(c) }
            .setNeutralButton("닫기", null)
            .create()

        dialog.show()
    }

    private fun confirmDelete(c: Customer) {
        AlertDialog.Builder(this)
            .setTitle("고객 삭제")
            .setMessage("${c.name} 고객을 삭제하시겠습니까?")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                val records = prefs.getStringSet("customers", emptySet())!!.toMutableSet()
                records.remove(encode(c))
                prefs.edit()
                    .putStringSet("customers", records)
                    .remove(paymentKey(c))
                    .apply()
                refreshCustomers()
            }
            .show()
    }
}
